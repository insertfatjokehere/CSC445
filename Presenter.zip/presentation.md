Space Communications
====================

Kyle Bashford & Dan Wysocki

CSC445

Spring 2014

!

Space Communications
====================

- the primary means of communication in space is with the use of satellites
- sattelites exist for a wide variety of purposes, and have different
  communication needs
- for a long time, there was little to no standardization on communication
  protocols in space
- CCSDS was formed to standardize data transmissions in space

<center>
![](img/Satellite.png)
</center>

!

Consultative Committee on Space Data Systems (CCSDS)
====================================================

- formed in 1982
- run by eleven space agencies
  - ASI (Italy)
  - CSA (Canada)
  - CNES (France)
  - CNSA (China)
  - DLR (Germany)
  - ESA (Europe)
  - INPE (Brazil)
  - JAXA (Japan)
  - NASA (United States)
  - RFSA (Russia)
  - UK Space Agency
- exists to develop standards for space communications
- over 600 space missions have used their protocols to date

!

Space Communications Protocol Specifications (SCPS)
===================================================

- set of extensions to standard terrestrial protocols, as well as new protocols
  designed for space
- SCPS-FP
  - extensions to FTP
- SCPS-TP
  - TCP and UDP options and modifications
  - compatible with well-behaved TCP implementations
- SCPS-SP
  - security protocol
- SCPS-NP
  - network protocol similar to IP

!

SCPS Protocol Stack
===================

<center>
![](img/SCPS-stack.png)
</center>

!

SCPS Uses
=========

The common usages of SCPS are:

  - space agency space networks
  - commercial satellite networks
  - private government satellite networks

!


SCPS-TP
=======

What is SCPS-TP?

  - SCPS-TP is TCP, with extensions, and UDP.

What are the benefits?

  - fully compatible wth existing TCP, with additional options on connection
    establishment
  - allows current networks to co-exist along with SCPS

Why use it?

  - easily appliable to spacecrafts/satellites in low bandwidth and/or
    error-prone environments

!

SCPS-TP
=======

SCPS is has its own set of rules that are used on top of TPC and UDP
specifications

  - a set of TCP options and sender-side modifications to improve TCP
    performance in stressed environments including long delays, high bit error
    rates, and significant asymmetries

  - the SCPS-TP options are TCP options registered with the Internet Assigned
    Numbers Authority (IANA) and hence SCPS-TP is compatible with other
    well-behaved TCP implementations

  - a SCPS-TP conforming implementation is not required to use a clock as the
    basis for Initial Sequence Number (ISN) selection

  - SACK (Selective ACK)
    - Allows receiver to tell the sender exactly what has been received
    - Better recovery when multiple segments are lost in a window

  - Selective Negative Acknowledgements (SNACKs)
    - reduced ack traffic after loss (good for asymmetric channels)

!

<center>
![](img/SCPS-TP-header.png)
</center>

<!-- NOTES
 describe picture here


  -->

!

<center>
![](img/tcp-comparison.png)
</center>


!

SCPS-NP
=======

The network protocol for SCPS (SCPS-NP for short) follow a specific guide line
on how transmittion are used

SCPS Address Family. The SCPS address family contains both End System
Addresses (identifying a single end system) and Path Addresses (identifying a
pair of communication systems). SCPS-family N-Addresses are structured as
follows:

!

SCPS-NP
=======

  - N-Addresses in the SCPS family are four octets in length and are represented
	inthis text as four eight-bit quantities separated by periods, e.g.,
	`w.x.y.z`, where the range of each of the alphabetic characters is from 0 to
	255 decimal
	- (the form `w.x.y.z` is the Extended form of a SCPS address)
  - The most-significant octet (the w octet) of a SCPS-family N-Address contains
	the value 10 (decimal), which is the value reserved by the Internet Assigned
	Numbers Authority (IANA) for private Internet address spaces.	

  - The x and y octets are combined to form the addressing domain for various
	programs; the `x.y` field is known as the Domain Identifier (D-ID).

!

SCPS-NP
=======

  - the `z` octet is administered by the program to which the D-ID is allocated
    and is subdivided as follows:
    - bits 0-6 form a field, which contains either an End System Identifier
	(ES-ID) or a Path Identifier (P-ID) in the range 0 to 126 (the value of 127
	is reserved for use in conjunction with the Multicast Flag to form the
	broadcast address)
    - bit 7 is the Multicast Flag (M-Flag), which signals whether the address is
	a multicast or unicast address
      - the M-Flag shall be set to '1' for multicast addresses
      - the M-Flag shall be set to '0' for unicast addresses

!

<center>
![](img/SCPS-NP-Datagram.png)
</center>

<!-- NOTES
  ##Anything thats greyed out is optional##

  VPI - Version/Protocol Identifier
  TP-ID - Transport Protocol ID Field
  Source Address (optional)
  BASIC QOS - Basic Quality of Service (optional)
  HOP Count (optional)
  Timestamp (optional)
  Expanded QOS (optional)
  Header Checksum (optional)
  -->

!


SCPS-FP
=======

- supports several data types

  - **General**: The non-print format controls are applicable to SCPS-FP

  - **ASCII Type**: The ASCII data type is optional for SCPS-FP file transfer
    operations; it does not apply to SCPS-FP record operations. The ASCII type
    is not the SCPS-FP default

  - **Image Type**: The IMAGE data type is the default for SCPS-FP and must be
    supported by all SCPS-FP implementations

  - **Data Connection Management**: The SCPS-FP user-PI must initiate the use of
    non-default ports because of the need for SCPS-TP to hold the connection
	record for a timeout period to guarantee reliable communication

  - **Stream Mode**: If the structure is a file structure, the EOF is indicated
    by the sending hosts closing of the data connection, in which case all bytes
	are data bytes

!

Networking
==========

<center>
![](img/End-to-End-SCPS.png)
</center>

!

Networking
==========

<center>
![](img/Single-Transport-Layer.png)
</center>

!
Networking
==========

<center>
![](img/Dual-Transport-Layer.png)
</center>

!

Disruption Tolerant Networking (DTN)
===

- developed by The Office of Space Communications and Navigation (SCaN)
- exerimental system designed to create an internet-esqe network for
  interplanitary communication
- delay and disruption tolerant
- first tested on the International Space Station (ISS)
- still being developed

!

DTN
===

- uses a different approach than TCP/IP
  - more resilient to disruption
- based on a new experimental protocol called the Bundle Protocol (BP)
  - BP sits at the application layer of constituent internets
  - forms a store-and-forward overlay network
  - operates as an overlay protocol that links together multiple subnets into
    a single network
- Store-And-Forward
  - endpoints aren't always continuously connected
  - to facilitate data transfer, store-and-forward approach is used across
    routers
- primary design uses
  - space vehicles
  - remote planetary habitats
  - rover vehicles
  - support infrastructure on a planetary surface

!

DTN Architecture
================

<center>
![](img/dtn-arch.png)
</center>

!

DTN - Video Explanation
=======================

[YouTube Link](http://www.youtube.com/watch?v=nWtRTzXJvtI&t=2m04s)

<!-- Video Notes

Only play from 2:04 to 3:12

-->

<center>
<iframe height="480" width="854" src="http://youtube.com/embed/nWtRTzXJvtI#t=128">
</iframe>
</center>

!

DTN
===

Examples of "DTN-friendly" network characteristics

  - frequently disconnected networks (sparse mobile networks)
  - long propagation (minutes to hours) delays (deep space links)
  - very low (a few kbps) throughputs (packet radio networks)
  - variable, possibly high bit rates (deep space links)
  - nodes with low duty cycles (sensor networks)
  - unidirectional links (simple sensors, probes)

!

DTN Applications
================

Space Applications

- a disruption tolerant architecture like DTN is necessary for future
  long-duration missions to the moon, asteroids, and other planets
- information must travel for long times and distances, leaving many
  opportunities for disruptions
- solar wind and radiation from the Sun and extra-solar sources can cause these
  disruptions

Earth Applications

- improve communications by ensuring no information is lost even when a
  connection is interrupted
- can improve communication in remote areas, benefitting
  - disaster-relief efforts
  - military
  - regions with limited communication infrastructure
- could be used for mobile phone-based pop-up networks, or MANETs
  (mobile ad hoc network)

!

Where DTN stands today
======================

November 8, 2012

NASA and the European Space Agency (ESA) successfully have used an experimental version of interplanetary Internet to control 
an educational LEGO rover from the International Space Station

<center>
![](img/legorobot.jpg)
</center>


