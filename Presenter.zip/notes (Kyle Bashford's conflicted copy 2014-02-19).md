# Source Links

[CCSDS - Wikipedia](https://en.wikipedia.org/wiki/CCSDS)

[SCPS - Wikipedia](https://en.wikipedia.org/wiki/Space_Communications_Protocol_Specifications)

[SCPS-FP Standard](http://public.ccsds.org/publications/archive/717x0b1s.pdf)

[SCPS-TP Standard](http://public.ccsds.org/publications/archive/714x0b2.pdf)

[SCPS-NP Standard](http://public.ccsds.org/publications/archive/713x0b1s.pdf)


# Draft



## Prologue

Since the beginning of space exploration, man made satellites were sent into space for telecommunication purposes








## Slide 1

- problems/differences with internet communications on earth vs space
  (ethernet/landline vs satelites)
- planets/asteroids/moons/solar flares interference blocking signal
- hardware faliure (e.g. atennas)
- no standards for communication protocol 

## Slide 2

- Consultative Committee for Space Data Systems (CCSDS)
- CCSDS was formed in 1982 Sets standards for space data systems
- Over 600 space mission ultilized their standards for space data systems

- The CCSDSs publications are grouped into six areas
  * Space Internetworking Services
  * Bullet Mission Ops. And Information Management Services
  * Spacecraft Onboard Interface Services
  * System Engineering
  * Cross Support Services
  * Space Link Services

- The most notable was Space Communications Protocol Specifications (SCPS)


## Slide 3

(Directly From Wikipedia, may need to be reworded)

The Space Communications Protocol Specifications (SCPS) are a set of extensions to existing protocols and new protocols 
developed by the Consultative Committee for Space Data Systems (CCSDS) to improve performance of 
Internet protocols in space environments. The SCPS protocol stack consists of:

SCPS-FP -- A set of extensions to FTP to make it more bit efficient and to add advanced features such as record update within a file and integrity checking on file transfers.

SCPS-TP -- A set of TCP options and sender-side modifications to improve TCP performance in stressed environments including long delays,
high bit error rates, and significant asymmetries. The SCPS-TP options are TCP options registered with the Internet Assigned Numbers Authority (IANA)
and hence SCPS-TP is compatible with other well-behaved TCP implementations.

SCPS-SP -- A security protocol comparable to IPsec

SCPS-NP -- A bit-efficient network protocol analogous to but not interoperable with IP

The SCPS protocol that has seen the most use commercially is SCPS-TP, usually deployed as a Performance Enhancing Proxy (PEP) to improve TCP performance over satellite links.

-The three primary markets for SCPS are as follows:
  -Space agency space networks
  -Commercial satellite networks 
  -Private government satellite networks
 
SCPS is a common request in large multiagency government satellite architectures in which a lowest common denominator approach to TCP acceleration is desirable. This enables the hub organization to provide basic TCP optimization to multiple agencies connecting into their teleports, without requiring a specific vendor solution.

## Slide 4

SCPS is has its own set of rules that are used on top of TPC and UDP (User Datagram Protocol) specifications

A SCPS-TP conforming implementation is not required to use a clock as the basis for Initial 
Sequence Number (ISN) selection

SCPS-TP adds more bits with transfer protocol to issue more options than a normal connection would

SACK (Selective ACK)
- Allows receiver to tell the sender exactly what has been received
- Better recovery when multiple segments are lost in a window


Selective Negative Acknowledgements (SNACKs)
 - reduced ack traffic after loss (good for asymmetric channels)

(Add picture from folder into this slide (may nees to be smaller if needed to))
(probably the picture with the satelite)

## Slide 5

the network protocol for SCPS (SCPS-NP for short) follow a specific guide line on how transmittion are used

#### Information below would need to be shortened or split into more slides

a) SCPS Address Family. The SCPS address family contains both End System
Addresses (identifying a single end system) and Path Addresses (identifying a pair of
communication systems). SCPS-family N-Addresses are structured as follows:

	1) N-Addresses in the SCPS family are four octets in length and are represented in
		this text as four eight-bit quantities separated by periods, e.g., w.x.y.z, where the
		range of each of the alphabetic characters is from 0 to 255 decimal.
		NOTE � The form w.x.y.z is the Extended form of a SCPS address.
	2) The most-significant octet (the w octet) of a SCPS-family N-Address contains the
		value 10 (decimal), which is the value reserved by the Internet Assigned Numbers
		Authority (IANA) for private Internet address spaces.	
	3) The x and y octets are combined to form the addressing domain for various
		programs; the x.y field is known as the Domain Identifier (D-ID).
	4) The z octet is administered by the program to which the D-ID is allocated and is
		subdivided as follows:
		� bits 0-6 form a field, which contains either an End System Identifier (ES-ID)
		or a Path Identifier (P-ID) in the range 0 to 126 (the value of 127 is reserved
		for use in conjunction with the Multicast Flag to form the broadcast address);
		� bit 7 is the Multicast Flag (M-Flag), which signals whether the address is a
		multicast or unicast address:
			� the M-Flag shall be set to �1� for multicast addresses;
			� the M-Flag shall be set to �0� for unicast addresses


## Slide 6

### This slide may be used for the FTP protocol for SPCS, but may need to discuss more about wether it is 
usefull to use


- Data Types

--- General
The non-print format controls are applicable to SCPS-FP.

--- ASCII Type

The ASCII data type is optional for SCPS-FP file transfer operations; it does not apply to
SCPS-FP record operations. The ASCII type is not the SCPS-FP default.

--- Image Type

The IMAGE data type is the default for SCPS-FP and must be supported by all SCPS-FP
implementations.


--- Data Connection Management
The SCPS-FP user-PI must initiate the use of non-default ports because of the need for
SCPS-TP to hold the connection record for a timeout period to guarantee reliable
communication.

--- Stream Mode

If the structure is a file structure, the EOF is indicated by the sending host�s closing of the
data connection, in which case all bytes are data bytes.


## Slide 7
The Disruption Tolerant Networking (DTN) program (The Office of Space Communications and Navigation (SCaN)) an
exerimental system designed to create an internet-esqe network for interplanitary communication (Delay- and disruption-tolerant networks).
(The system is first tested on the Internation Space Station (ISS) and still being developed) 


### (next 2 sections blantenly copy pasted from: http://www.webopedia.com/TERM/D/Disruption_Tolerant_Networking.html)

A Different Approach to TCP/IP

DTN works using different kind of approach than TCP/IP for packet delivery that is more resilient to disruption than TCP/IP. 
DTN is based on a new experimental protocol called the Bundle Protocol. The Bundle Protocol (BP) sits at the application layer of some number of constituent internets, 
forming a store-and-forward overlay network. BP operates as an overlay protocol that links together multiple subnets (such as Ethernet-based LANs) into a single network.



Store-And-Forward

The basic idea behind DTN network is that endpoints arent always continuously connected. 
In order to facilitate data transfer, DTN uses a store-and-forward approach across routers that is more disruption-tolerant than TCP/IP.
However, the DTN approach doesnt necessarily mean that all DTN routers on a network would require large storage capacity in order to maintain end-to-end data integrity.

The system is design primairly for space vehicles, remote planetary habitats, rover vehicles and support infrastructure on a planetary surface.



## Slide 8

Examples of �DTN-friendly� network characteristics
� Frequently disconnected networks (sparse mobile networks)
� Long propagation (eg. minutes) delays (deep space links)
� Very low (a few kb/s) throughputs (packet radio networks)
� Variable, possibly high (10^-3 and more) bit rates (deep space
links)
� Nodes with low duty cycles (sensor networks)
� Unidirectional links (simple sensors, probes)


## Slide 9

###Applications for DTN (blantenly copy pasted from: http://www.nasa.gov/mission_pages/station/research/experiments/730.html)

Space Applications
A networked architecture such as DTN is required for future long-duration missions to the moon, asteroids and Mars. 
Information takes a long time to travel across interplanetary distances, and this can cause interruptions. 
Even with a good connection between Earth and space-based assets, radiation from the sun or other cosmic sources can interfere with radio signals.
Experiments with DTN can help scientists develop Internet-like communications with space probes, rovers, and even remote planetary habitats. 

Earth Applications

Disruption-tolerant networks improve communications by ensuring no information is lost even when a connection is interrupted. 
Such networks can improve communication in remote areas, which could benefit the military, disaster-relief efforts, and people living in regions
 with limited communications infrastructure. The communications methods developed for DTN could be used for mobile phone-based pop-up networks, or MANETs.

## Slide 10

Where DTN stands today

November 8, 2012

NASA and the European Space Agency (ESA) successfully have used an experimental version of interplanetary Internet to control 
an educational LEGO rover from the International Space Station










